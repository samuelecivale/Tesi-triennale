/**
 * @file Modules/Modeling/MessageManager/MessageManager.cpp
 *
 * Implementation of the .h
 * 
 * INCOMING CHANGES
 * - Nuovo evento di Graziano
 * 
 * @author Francesco Petri
 */

#include "MessageManager.h"

MessageManager::MessageManager() {}

void MessageManager::update(MessageManagement& mm)
{
  ///// those who see the ball send at a higher rate
  if (theFrameInfo.getTimeSince(theBallModel.timeWhenLastSeen) < ballSeenTimeThreshold) {
    mm.sendInterval = sendIntervalIfBallSeen;
  }
  else {
    mm.sendInterval = sendIntervalIfNoBall;
  }


  ///// check conditional events
  bool is_searcher = thePlayerRole.role== thePlayerRole.role==PlayerRole::activeSearcher || thePlayerRole.role==PlayerRole::passiveSearcher;

  // striker sends a message when it detects a goal
  bool conditionalEvent_strikerDetectedGoal = (theWhistle.lastTimeGoalDetected > mm.lastEventTS && (thePlayerRole.role == PlayerRole::striker || thePlayerRole.role == PlayerRole::activeSearcher));
  // anyone sends a message when it exits search mode after seeing the ball
  bool conditionalEvent_searcherSawBall = (was_searcher && !is_searcher && theFrameInfo.getTimeSince(theBallModel.timeWhenLastSeen) < 500);
  // EVERYONE sends a message after the ball is first seen by the team after being unseen for a while
  bool conditionalEvent_teamSawBallAfterAWhile = (
    !teamBall_isValid_prev &&
    theTeamBallModel.isValid &&
    theFrameInfo.getTimeSince(teamBall_timeLastSeen_prev) > teamBallNotSeenThreshold &&
    theFrameInfo.getTimeSince(lastTeamBallEventTS) > teamBallNotSeenThreshold
  );

  if (conditionalEvent_teamSawBallAfterAWhile) {
    lastTeamBallEventTS = theFrameInfo.time;
  }

  // so we have only one place where to list conditional events
  bool anyConditionalEvent = (
    conditionalEvent_strikerDetectedGoal ||
    conditionalEvent_searcherSawBall ||
    conditionalEvent_teamSawBallAfterAWhile
  );

  // Fire event!
  if (anyConditionalEvent) {
    mm.lastEventTS = theFrameInfo.time;
  }

  // if (conditionalEvent_strikerDetectedGoal) {
  //   SystemCall::say("Goal event triggered");
  // }

  // if (conditionalEvent_searcherSawBall) {
  //   SystemCall::say("Searcher event activated");
  // }


  ///// notify the emergency that there are no packets left
  // ...but only for real robots w/ a real gamecontroller, otherwise it's a strikerfest in the sim
  #ifdef TARGET_ROBOT
  mm.outOfPackets = theOwnTeamInfo.messageBudget <= outOfPacketsThreshold;
  #else
  mm.outOfPackets = false;
  #endif

  was_searcher = is_searcher;
  teamBall_isValid_prev = theTeamBallModel.isValid;
  teamBall_timeLastSeen_prev = theTeamBallModel.timeWhenLastSeen;
}

MAKE_MODULE(MessageManager, modeling);