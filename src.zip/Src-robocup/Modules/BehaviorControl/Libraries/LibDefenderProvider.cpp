/**
 * @file LibDefenderProvider.cpp
 * 
 * See LibDefender
 *
 * @author Francesco Petri
 */

#include "LibDefenderProvider.h"

MAKE_MODULE(LibDefenderProvider, behaviorControl);

void LibDefenderProvider::update(LibDefender& libDefender)
{
  libDefender.defenderDynamicDistance = [this]() -> float {
    return defenderDynamicDistance();
  };
  libDefender.defenderDynamicY = [this]() -> float {
    return defenderDynamicY();
  };
  libDefender.getDefenderPosition = [this]() -> Vector2f {
    return getDefenderPosition();
  };
  libDefender.angleForDefender =[this]() -> float {
    return angleForDefender();
  };
}

float LibDefenderProvider::angleForDefender() const {
  Vector2f defenderPosition = getDefenderPosition();
  return theLibMisc.angleToTarget(defenderPosition.x(), defenderPosition.y());
}


float LibDefenderProvider::defenderDynamicDistance() const {
  float x1 = theRobotPose.translation.x();
  float y1 = theRobotPose.translation.y();
  float x3 = theTeamBallModel.position.x();
  float y3 = theTeamBallModel.position.y();
  float x2 = (float)theFieldDimensions.xPosOwnGroundLine;   // first goalpost for defender
  float y2 = (y3/(std::abs(y3)+1))*750.f;  // first goalpost for defender
  float m = (y1-y2)/(x1-x2) ;
  float q = y1 - (((y1-y2)/(x1-x2))*x1) ;


  float distance = std::abs( y3 - (m*x3 +q) )/(std::sqrt( 1 + (m*m) ));

  return distance;
}

float LibDefenderProvider::defenderDynamicY() const {
  Vector2f defenderPosition = getDefenderPosition();
  float x2 = theTeamBallModel.position.x();
  float y2 = theTeamBallModel.position.y();
  float x1 = -4500.f;   // first goalpost for defender
  float y1 = (y2/(std::abs(y2)+1))*750.f;   // first goalpost for defender
  float defenderBallY = (( defenderPosition.x()-x1 )*( y2-y1 ))/( x2-x1 ) + y1;

  return defenderBallY-(y2/(std::abs(y2)+1))*100.f;
}

Vector2f LibDefenderProvider::getDefenderPosition() const {
  float def_x = 0;
  if(theFieldBall.recentBallPositionOnField().x() > theFieldDimensions.xPosOwnGoalArea/2.0f){
    def_x = (theFieldDimensions.xPosOwnGoalArea + theFieldDimensions.xPosOwnPenaltyMark)/2.0f;
  }else{
    def_x = (theFieldDimensions.xPosOwnGroundLine + theFieldDimensions.xPosOwnPenaltyMark)/2.0f;
  }
        
  Line2 ball_goal = Line2::Through(theFieldBall.recentBallPositionOnField(), Vector2f(theFieldDimensions.xPosOwnGroundLine, 0.f));
  Line2 parallel = Line2::Through(Vector2f(def_x, -300.f), Vector2f(def_x, 300.f));

  return ball_goal.intersection(parallel);
}