/**
 * @file LibSupporterProvider.cpp
 * 
 * See LibSupporter
 *
 * @author Francesco Petri
 */

#include "LibSupporterProvider.h"
#include <iostream>

MAKE_MODULE(LibSupporterProvider, behaviorControl);

void LibSupporterProvider::update(LibSupporter& libSupporter)
{
  libSupporter.getSupporterPosition = [this]() -> Vector2f {
    return getSupporterPosition();
  };

  libSupporter.angleForSupporter = [this]() -> float {
    return angleForSupporter();
  };
}

// Unused
float LibSupporterProvider::distanceToLine(Vector2f objectToCheck, Vector2f linePoint1, Vector2f linePoint2) const {
  return std::abs(((linePoint2.y()-linePoint1.y())*objectToCheck.x()) - ((linePoint2.x() - linePoint1.x()) * objectToCheck.y())
    + (linePoint2.x() * linePoint1.y()) - (linePoint2.y() * linePoint1.x())) / ((linePoint1-linePoint2).norm());
}


Vector2f LibSupporterProvider::getSupporterPosition() const {
  Pose2f target;
  if(theFieldBall.recentBallPositionOnField().x() > theFieldDimensions.xPosOwnGoalArea){
    target = theLibMisc.glob2Rel(theFieldBall.recentBallPositionOnField().x() - 1000.f, theFieldBall.recentBallPositionOnField().y());     
  }else{
    if(theFieldBall.recentBallPositionOnField().y() > 0){
      target = theLibMisc.glob2Rel(theFieldDimensions.xPosOwnGoalArea, theFieldDimensions.yPosLeftGoal);
    }else{
      target = theLibMisc.glob2Rel(theFieldDimensions.xPosOwnGoalArea, theFieldDimensions.yPosRightGoal);
    }       
  }
  return target.translation;
}

float LibSupporterProvider::angleForSupporter() const{
  Vector2f supporterPosition = getSupporterPosition();
  return theLibMisc.angleToTarget(supporterPosition.x(), supporterPosition.y());
}