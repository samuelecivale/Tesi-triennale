/**
 * @file LibDefenderProvider.h
 * 
 * See LibDefender
 *
 * @author Francesco Petri
 */

#pragma once

#include "Representations/Modeling/RobotPose.h"
#include "Representations/Configuration/FieldDimensions.h"
#include "Representations/Modeling/TeamBallModel.h"
#include "Representations/BehaviorControl/Libraries/LibMisc.h"
#include "Representations/BehaviorControl/Libraries/LibDefender.h"
#include "Tools/Module/Module.h"
#include "Representations/BehaviorControl/FieldBall.h"
#include "Representations/Configuration/FieldDimensions.h"

using Line2 = Eigen::Hyperplane<float,2>;


MODULE(LibDefenderProvider,
{,
  REQUIRES(RobotPose),
  REQUIRES(FieldDimensions),
  REQUIRES(TeamBallModel),
  REQUIRES(LibMisc),
  REQUIRES(FieldBall),
  PROVIDES(LibDefender),
  // LOADS_PARAMETERS(
  // {,
  //   // nothing for now!
  // }),
});

class LibDefenderProvider : public LibDefenderProviderBase
{
private:
  
  /**
   * Updates LibDefender
   * @param libDefender The representation provided
   */
  void update(LibDefender& libDefender) override;


  // ===== IMPLEMENTATIONS OF LibDefender =====

  /** 
   * <no doc was available, this is a guess>
   * Distance of the ball from some ideal line  (connecting defender pos and goalpost?)
   * Supposedly, some quantity the defender strives to minimize.
   * TODO this is likely to end up unused, check after porting
   */
  float defenderDynamicDistance() const;

  /** 
   * <no doc was available, this is a guess>
   * Returns the ideal y for the defender to block the most direct shot
   * from the ball to the goal.
   * TODO this is likely to end up unused, check after porting
   */
  float defenderDynamicY() const;     // this gets the libDefender parameter b/c it needs to read something


  /** 
   * Provides the defender reference position based on 
   * intersection between of the center of 
   * the ball and the center of the goal
   */
  Vector2f getDefenderPosition() const;

  /** 
   * Holds the angle between robot's current position and reference defender position.
   */
  float angleForDefender() const;
};
