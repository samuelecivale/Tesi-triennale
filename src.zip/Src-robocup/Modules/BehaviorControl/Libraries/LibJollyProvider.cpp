/**
 * @file LibJollyProvider.cpp
 * 
 * See LibJolly
 *
 * @author Francesco Petri
 */

#include "LibJollyProvider.h"
#include <iostream>

MAKE_MODULE(LibJollyProvider, behaviorControl);

void LibJollyProvider::update(LibJolly& libJolly)
{
  libJolly.getJollyPosition = [this]() -> Vector2f {
    return getJollyPosition();
  };

  libJolly.angleForJolly = [this]() -> float {
    return angleForJolly();
  };
}


Vector2f LibJollyProvider::getJollyPosition() const {
  Pose2f target;
  if(theFieldBall.recentBallPositionOnField().y() > 0){
    //follow ball right
    if(theFieldBall.recentBallPositionOnField().x() > theFieldDimensions.xPosOwnGoalArea){
      target = theLibMisc.glob2Rel(clip(theFieldBall.recentBallPositionOnField().x() + 700.f, theFieldDimensions.xPosOwnPenaltyMark,
      theFieldDimensions.xPosOpponentPenaltyMark), theFieldBall.recentBallPositionOnField().y() -800.f);        
    }else{
      target = theLibMisc.glob2Rel(theFieldDimensions.xPosOwnGoalArea/1.5, theFieldDimensions.yPosLeftGoal);
    }
  }
  else{
    //follow ball left
    if(theFieldBall.recentBallPositionOnField().x() > theFieldDimensions.xPosOwnGoalArea){
      target = theLibMisc.glob2Rel(clip(theFieldBall.recentBallPositionOnField().x() + 700.f, theFieldDimensions.xPosOwnPenaltyMark,
      theFieldDimensions.xPosOpponentPenaltyMark), theFieldBall.recentBallPositionOnField().y() +800.f);
    }else{
      target = theLibMisc.glob2Rel(theFieldDimensions.xPosOwnGoalArea/1.5, theFieldDimensions.yPosRightGoal);
    }
  }

  return target.translation;
}

float LibJollyProvider::angleForJolly() const {
  Vector2f jollyPosition = getJollyPosition();
  return theLibMisc.angleToTarget(jollyPosition.x(), jollyPosition.y());;
}
