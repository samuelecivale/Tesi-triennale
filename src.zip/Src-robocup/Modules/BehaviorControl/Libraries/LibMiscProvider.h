/**
 * @file LibMiscProvider.h
 * 
 * See LibMisc
 *
 * @author Francesco Petri
 */

#pragma once

#include "Representations/Modeling/RobotPose.h"
#include "Representations/BehaviorControl/FieldBall.h"
#include "Representations/Configuration/FieldDimensions.h"
#include "Representations/BehaviorControl/Libraries/LibMisc.h"
#include "Tools/Module/Module.h"

MODULE(LibMiscProvider,
{,
  REQUIRES(RobotPose),
  REQUIRES(FieldBall),
  REQUIRES(FieldDimensions),
  PROVIDES(LibMisc),
  // LOADS_PARAMETERS(
  // {,
  //   // nothing for now!
  // }),
});

class LibMiscProvider : public LibMiscProviderBase
{
private:
  
  /**
   * Updates LibMisc
   * @param libMisc The representation provided
   */
  void update(LibMisc& libMisc) override;

  /** Returns -1 if the direction points to the own field, 1 if it points to the opponent field **/
  int localDirectionToField(const Vector2f& localDirection) const;

  /** Provides the distance between 2 Pose2f **/
  float distance(const Pose2f& p1, const Pose2f& p2) const;

  //Maps value from interval [fromIntervalMin, fromIntervalMax] to interval [toIntervalMin, toIntervalMax]
  float mapToInterval(float value, float fromIntervalMin, float fromIntervalMax, float toIntervalMin, float toIntervalMax) const;

  /**
   * Checks if currentValue is close enough to target.
   * bound indirectly determines the tolerance.
   */
  bool isValueBalanced(float currentValue, float target, float bound) const;

  /**
   * Calculates the angle of the given point wrt the robot position and orientation.
   * Point to be given in global coordinates.
   */
  float angleToTarget(float x, float y) const;

  /**
   * Transforms a position in global (field) coordinates into local (robot) coordinates.
   */
  Pose2f glob2Rel(float x, float y) const;

  /**
   * Transforms a position in local (robot) coordinates into global (field) coordinates.
   */
  Pose2f rel2Glob(float x, float y) const;

  /**
   * Computes the norm of vector (x,y).
   */
  float norm(float x, float y) const;

  /**
   * Converts an angle from radians to degrees.
   */
  float radiansToDegree(float x) const;

  /**
   * Angle of the line passing through two points.
   * WARNING: [torch, 2022]
   *     Something about the implementation doesn't convince me.
   *     See LibMiscProvider.cpp for details.
   *     Anyway, this is used in a couple modules, so I can't change this at the moment.
   *     Future users, make sure this is really what you want before using this.
   */
  float angleBetweenPoints(const Vector2f& p1, const Vector2f& p2) const;

  /**
   * Angle between two vectors in radians 
   */
  float angleBetweenVectors(const Vector2f& v1, const Vector2f& v2) const;
};
