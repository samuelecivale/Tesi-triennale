/**
 * @file CameraImage.cpp
 *
 * This file should be made obsolete as soon as possible.
 *
 * @author Arne Hasselbring
 */

#include "CameraImage.h"

constexpr unsigned int CameraImage::maxResolutionWidth;
constexpr unsigned int CameraImage::maxResolutionHeight;
