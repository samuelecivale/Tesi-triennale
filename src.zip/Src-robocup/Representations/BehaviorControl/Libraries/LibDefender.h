/**
 * @file LibDefender.h
 *
 * This file defines a representation that holds some utilities (primarily) for the defender.
 *
 * @author Francesco Petri
 */

#pragma once

#include "Tools/Function.h"
#include "Tools/Math/Eigen.h"
#include "Tools/Streams/AutoStreamable.h"

STREAMABLE(LibDefender,
{
  /** 
   * <no doc was available, this is a guess>
   * Distance of the ball from some ideal line  (connecting defender pos and goalpost?)
   * Supposedly, some quantity the defender strives to minimize.
   * TODO this is likely to end up unused, check after porting
   */
  FUNCTION(float()) defenderDynamicDistance;

  /** 
   * <no doc was available, this is a guess>
   * Returns the ideal y for the defender to block the most direct shot
   * from the ball to the goal.
   * TODO this is likely to end up unused, check after porting
   */
  FUNCTION(float()) defenderDynamicY;


  /** 
   * Provides the defender reference position based on 
   * intersection between the center of 
   * the ball and the center of the goal
   */
  FUNCTION(Vector2f()) getDefenderPosition;

  /** 
   * Holds the angle between robot's current position and reference defender position.
   */
  FUNCTION(float()) angleForDefender,
});
