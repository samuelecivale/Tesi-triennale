/**
 * @file PlayerRole.h
 *
 * This file declares a representation of a player's role.
 *
 * @author Arne Hasselbring
 */

#pragma once

#include "Tools/Streams/AutoStreamable.h"
#include "Tools/Streams/Enum.h"
#include "Tools/Communication/BHumanTeamMessageParts/BHumanMessageParticle.h"
#include <string>
#define magic_value -999999

STREAMABLE(PlayerRole, COMMA public PureBHumanArbitraryMessageParticle<idPlayerRole>
{
  ENUM(RoleType,
  {,
    // THE PREEXISTING ONES
    // (TODO remove the removable ones at the end of the porting)
    none,
    goalkeeper,
    ballPlayer,
    // legacy roles from 2019
    firstSupporterRole,
    supporter0 = firstSupporterRole,
    supporter1,
    supporter2,
    supporter3,
    supporter4,

    // OURS
    undefined,
    goalie,
    striker,
    defender,
    supporter,
    jolly,
    penaltyStriker,
    penaltyKeeper,
    planStriker,
    planJolly,
    activeSearcher,
    passiveSearcher,
    // we have a "none" as well. Maybe redundant w/ undefined? Should we pick one? [torch]
  });

  ENUM(Context,
  {,
    no_context,
    playing,
    search_for_ball,
  });

  std::string getName() const;

  static int getUtilityMatrixRowIndex(RoleType role);

  /** BHumanMessageParticle functions (SPQR) */
  void operator>>(BHumanMessage& m) const override;

  // normally there would be handleArbitraryMessage here, but this case is special
  // in that the Teammate struct will not have the full thePlayerRole field
  // but just a role field of type RoleType. No need for the full representation.
  // In the interest of putting sending and receiving close to each other, however,
  // this function is put here as the closest possible thing to handleArbitraryMessage.
  static RoleType specialHandlingOfArbitraryMessage(InMessage& m);

  /**
   * Compatibility function for (B-Human) 2019 behavior.
   * @return Whether the robot is goalkeeper.
   */
  bool isGoalkeeper() const
  {
    return role == goalkeeper || role == goalie;
  }

  /**
   * Compatibility function for (B-Human) 2019 behavior.
   * @return Whether the robot plays the ball.
   */
  bool playsTheBall() const
  {
    return role == ballPlayer || role == striker;
  }

  /**
   * Compatibility function for (B-Human) 2019 behavior.
   * NOTE: Only used in LEDHandler. TODO remove at the end of porting.
   * @return The robot's supporter index.
   */
  int supporterIndex() const
  {
    return role < firstSupporterRole ? -1 : (role - firstSupporterRole);
  },

  (RoleType)(none) role, /**< The role type. */
  (RoleType)(undefined) lastRole,
  (Context)(no_context) current_context,
  (std::vector<int>)(5,0) utility_vector,
  (std::vector<Pose2f>)(std::vector<Pose2f>(5,Pose2f(magic_value,magic_value,magic_value))) robots_poses,

  // TODO we don't know what to make of this, right? Remove this? [torch]
  (int)(0) numOfActiveSupporters, /**< The number of not penalized supporters (i.e. robots that have a supporterIndex >= 0). */
});
