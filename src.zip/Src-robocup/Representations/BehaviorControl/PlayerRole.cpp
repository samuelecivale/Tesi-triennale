/**
 * @file PlayerRole.cpp
 *
 * @author Arne Hasselbring
 */

#include "PlayerRole.h"
#include "Platform/BHAssert.h"

std::string PlayerRole::getName() const
{
  // switch (role) {
  //   case undefined:        return "undefined";
  //   case goalie:           return "goalie";
  //   case striker:          return "striker";
  //   case defender:         return "defender";
  //   case supporter:        return "supporter";
  //   case jolly:            return "jolly";
  //   case activeSearcher:   return "activeSearcher";
  //   case passiveSearcher:  return "passiveSearcher";
  //   case penaltyStriker:   return "penaltyStriker";
  //   case penaltyKeeper:    return "penaltyKeeper";
  //   case planStriker:      return "planStriker";
  //   case planJolly:        return "planJolly";
  //   case none:             return "none";
  //   default:               return "UPDATE PlayerRole::getName !!!";
  // }

  return TypeRegistry::getEnumName(role);
}

void PlayerRole::operator>>(BHumanMessage& m) const
{
  m.theBHumanArbitraryMessage.queue.out.bin << role;

  m.theBHumanArbitraryMessage.queue.out.finishMessage(this->id());
}

PlayerRole::RoleType PlayerRole::specialHandlingOfArbitraryMessage(InMessage& m)
{
  ASSERT(m.getMessageID() == id());

  RoleType receivedRole;
  m.bin >> receivedRole;

  return receivedRole;
}

int PlayerRole::getUtilityMatrixRowIndex(PlayerRole::RoleType role){
  switch (role)
  {
  case striker:
    return 2;
    break;
  case defender:
    return 3;
    break;
  case supporter:
    return 4;
    break;
  case jolly:
    return 5;
    break;
  default:
    ASSERT(0 && " Role not used in Utility Matrix Computation");
    return -1;
    break;
  }
};

