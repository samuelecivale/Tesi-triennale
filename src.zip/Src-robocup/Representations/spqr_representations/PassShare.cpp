/**
 * @file PassShare.cpp
 */

// TODO PORT THIS

#include "PassShare.h"

void PassShare::draw() const {
  ;
}